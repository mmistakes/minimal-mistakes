INSTALLATION

Copy the folder "vpilotdesigns-xxxx" to your community folder. 

Path for Gamepass/Windows Store:
C:\Users\YourUsername\AppData\Local\Packages\Microsoft.FlightSimulator_xxxxxxxxxxxx\LocalCache\Packages\Community

Path for Steam version:
C:\Users\YourUsename\AppData\Local\Packages\Microsoft.FlightDashboard_xxxxxxxxxxxxxx\LocalCache\Packages\Community

If you encounter any problems delete this folder from the "Community" folder.

This scenery is for personal, non-commercial use only.
You are not allowed to redistribute any part of this package without permission.

Consider supporting me with a donation:

https://streamlabs.com/v_pilot/tip

Contact:

Discord 

Channel: https://discord.gg/uPBWUyw
User: V-Pilot#7116

INSTALACION

Copiar el folder "vpilotdesigns-xxxx" al community folder de MSFS

Directorio para MSFS de Gamepass/Windows Store:
C:\Users\YourUsername\AppData\Local\Packages\Microsoft.FlightSimulator_xxxxxxxxxxxx\LocalCache\Packages\Community

Directorio para MSFS Steam version:
C:\Users\YourUsename\AppData\Local\Packages\Microsoft.FlightDashboard_xxxxxxxxxxxxxx\LocalCache\Packages\Community

Si hay algun problema con este addon, borrat esta carpeta del directorio "Community"

Este escenario es para uso personal, se prohibe la distribución comercial completa o parcial sin mi permiso.

Considera apoyarme con una donación:

https://streamlabs.com/v_pilot/tip

Contacto

Discord 

Canal: https://discord.gg/uPBWUyw
User: V-Pilot#7116
